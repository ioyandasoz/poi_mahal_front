package com.poi_mahal;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

System.register(["./index-legacy-Ceq3s_hA.js"],(function(e,i){"use strict";var n;return{setters:[e=>{n=e.w}],execute:function(){
/*!
             * (C) Ionic http://ionicframework.com - MIT License
             */
var i,t;!function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"}(i||(i={})),e("a",t),function(e){e.Body="body",e.Ionic="ionic",e.Native="native",e.None="none"}(t||e("a",t={})),e("K",{getEngine(){const e=(()=>{if(void 0!==n)return n.Capacitor})();if(null==e?void 0:e.isPluginAvailable("Keyboard"))return e.Plugins.Keyboard},getResizeMode(){const e=this.getEngine();return(null==e?void 0:e.getResizeMode)?e.getResizeMode().catch((e=>{if(e.code!==i.Unimplemented)throw e})):Promise.resolve(void 0)}})}}}));
